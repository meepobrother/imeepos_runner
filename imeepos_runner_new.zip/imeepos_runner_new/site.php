<?php
/**
 * 小明跑腿模块微站定义
 *
 * @author imeepos
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Imeepos_runner_newModuleSite extends WeModuleSite {

	public function doMobileIndex() {
		global $_W,$_GPC;
		include $this->template('index');
	}
	public function doMobileHome() {
		global $_W,$_GPC;
		include $this->template('index');
	}
	public function doWebIndex() {
		global $_W,$_GPC;
		include $this->template('web/index');
	}

}